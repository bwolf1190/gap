	<div id="social-left">
			<div><a href="https://www.facebook.com/GreatAmericanPower/" target="_blank"><i class="fa fa-facebook"></i></a></div>
			<div><a href="https://twitter.com/GreatAmeriPower" target="_blank"><i class="fa fa-twitter"></i></a></div>
			<div><a href="https://www.linkedin.com/company/1855714" target="_blank"><i class="fa fa-linkedin"></i></a></div>
			<div><a href="https://www.pinterest.com/grtamerpwr/" target="_blank"><i class="fa fa-pinterest"></i></a></div>
	</div>

