<!-- Zip Field -->
<div class="form-group">
    {!! Form::label('zip', 'Zip:') !!}
    <p>{!! $zip->zip !!}</p>
</div>

<!-- Ldc Id Field -->
<div class="form-group">
    {!! Form::label('ldc_id', 'Ldc Id:') !!}
    <p>{!! $zip->ldc_id !!}</p>
</div>

