

        {!! Charts::assets() !!}


            {!! $chart->render() !!}
