<div class="form-group">
    {!! Form::label('name', 'Name:') !!}
    <p>{!! $subagent->name !!}</p>
</div>

<div class="form-group">
    {!! Form::label('email', 'Email:') !!}
    <p>{!! $subagent->email !!}</p>
</div>



