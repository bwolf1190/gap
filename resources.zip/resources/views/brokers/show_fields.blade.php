<div class="form-group">
    {!! Form::label('name', 'Name:') !!}
    <p>{!! $broker->name !!}</p>
</div>

<div class="form-group">
    {!! Form::label('promo', 'Promo:') !!}
    <p>{!! $broker->promo !!}</p>
</div>



