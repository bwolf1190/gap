<div class="container">
	<div>
		<p>
			{!! $inquiry !!}
		</p>
		<br><br>
		<p>
			Name: {!! $name !!}<br>
			Email: {!! $email !!}<br>
			Phone: {!! $phone !!}<br>
		</p>
	</div>
</div>


