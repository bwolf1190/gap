<?php

	 echo $response;

	echo "it worked... kind of";
?>