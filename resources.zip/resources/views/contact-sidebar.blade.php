    <div id="contact-sidebar" class="col-xs-2">
    	<div class="section row">
    		<h2>Contact</h2>
    	</div>
    	<div class="row">
    		<div class="col-xs-2">
            	<i class="fa fa-phone"></i>
            </div>
            <div class="col-xs-9 col-xs-offset-1">
            	<p>1-877-215-4140</p>
            </div>
    	</div>
    	<div class="row">
    		<div class="col-xs-2">
            	<i class="fa fa-envelope"></i>
            </div>
            <div class="col-xs-9 col-xs-offset-1">
            	<p><a href="mailto:GAPOnline@GreatAmericanPower.com">Email Us</a></p>
            </div>
    	</div>
    	<div class="row">

    	</div>
    </div> 