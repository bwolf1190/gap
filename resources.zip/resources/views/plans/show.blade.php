@extends('master')

@section('content')
<div class="container">
	 @include('plans.show_fields')
</div>
@endsection
