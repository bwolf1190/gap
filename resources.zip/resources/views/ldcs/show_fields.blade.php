<!-- Ldc Field -->
<div class="form-group">
    {!! Form::label('ldc', 'Ldc:') !!}
    <p>{!! $ldc->ldc !!}</p>
    <p>{!! $ldc->customer_identifier !!}</p>
    <p>{!! $ldc->format_criteria_1 !!}</p>
    <p>{!! $ldc->format_criteria_2 !!}</p>
</div>

