<?php

	echo phpinfo();

?>