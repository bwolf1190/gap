@extends('master-2')
@section('navbar-brand')
<a id="nav-brand" href="/"> {!! Html::image('images/gap-fcp.png', 'great-american-power-freedom-choice-power') !!}</a>
@endsection
@section('content')
<div class="row">
    <!-- === BEGIN CONTENT === -->
    <div id="content" class="container">
        <div class="row margin-top-30">
        </div>
        <div class="row margin-top-10">
            <!-- Carousel Slideshow -->
            <div id="carousel-example" class="carousel slide" data-ride="carousel">
                <!-- Carousel Indicators -->
                <ol class="carousel-indicators">
                    <li data-target="#carousel-example" data-slide-to="0" class="active"></li>
                    <li data-target="#carousel-example" data-slide-to="1"></li>
                    <li data-target="#carousel-example" data-slide-to="2"></li>
                </ol>
                <!-- End Carousel Indicators -->
                <!-- Carousel Images -->
                <div class="carousel-inner">
                    <div class="item active">
                        {!! Html::image('images/house-lights.jpg', 'slide1') !!}
                    </div>
                    <div class="item">
                        {!! Html::image('images/office-short.jpg', 'slide2') !!}
                    </div>
                    <div class="item">
                        {!! Html::image('images/bakery-short.jpg', 'slide1') !!}
                    </div>
                </div>
                <!-- End Carousel Images -->
                <!-- Carousel Controls -->
                <a class="left carousel-control" href="#carousel-example" data-slide="prev">
                    <span class="glyphicon glyphicon-chevron-left"></span>
                </a>
                <a class="right carousel-control" href="#carousel-example" data-slide="next">
                    <span class="glyphicon glyphicon-chevron-right"></span>
                </a>
                <!-- End Carousel Controls -->
            </div>
            <!-- End Carousel Slideshow -->
        </div>
        <div class="row margin-vert-30">
            <div id="sign-up-container">
                <h2>Find Your Rate</h2>
                {!! Form::open(['action' => 'LdcController@search']) !!}
                {!! csrf_field() !!}
                <div id="sign-up-form" class="">
                    <div id="zip" class="form-group col-sm-5">
                        {!! Form::text('zip', 'Zip Code', ['class' => 'form-control']) !!}
                    </div>
        <div class="row">
            <div class="form-group col-xs-6 col-sm-6">
                <input id="next" type="submit" name="Commercial" value="Commercial">
                <input id="next" type="submit" name="Residential" value="Residential">
            </div>
        </div>
                </div>
                {!! Form::close() !!}
            </div>
        </div>
        <div class="row margin-vert-30">
            <!-- Main Text -->
            <div class="col-md-9">
                <h2>What We Do</h2>
                <p>Great American Power is an Electric Supply company focusing on the US states with deregulation. We believe in hiring the right people for the job which in turn means our clients get the best possible services and products. We understand that electricity service is not an option, it is an essential service and is something our clients must therefore pay close attention to manage and control costs, now and in the foreseeable future.</p>
                <p>Our staff is Empowered, Educated, and Experienced. When you speak with one, you will remember the experience and it is our goal that you will also know more than you did before the conversation. We also hope that you will stay in touch with us and let us know what else we can do to earn your business!</p>
                <a class="btn btn-default" href="#">
                    Read More
                    <i class="fa-chevron-right"></i>
                </a>
            </div>
            <!-- End Main Text -->
            <!-- Side Column -->
            <div class="col-md-3">
                <h3 class="margin-bottom-10">Links</h3>
                <ul class="menu">
                    <li>
                        <a class="fa-angle-right" href="#" >Enroll</a>
                    </li>
                    <li>
                        <a class="fa-angle-right" href="#" >About</a>
                    </li>
                    <li>
                        <a class="fa-angle-right" href="#" >FAQ</a>
                    </li>
                    <li>
                        <a class="fa-angle-right" href="#" >Contact</a>
                    </li>
                </ul>
            </div>
            <!-- End Side Column -->
        </div>
        <div class="row">
            <!-- Portfolio -->
            <!-- Portfolio Item -->
            <div class="portfolio-item col-sm-4 animate fadeIn">
                <div class="image-hover">
                    <a href="#">
                        <figure>
                            {!! Html::image('images/enroll-square.png', 'enroll-now', array('class' => 'img-square img-responsive img-center enroll')) !!}
                            <div class="overlay">
                                <a class="expand" href="#">Image Link</a>
                            </div>
                        </figure>
                        <h3 class="margin-top-20">Enroll Now</h3>
                        <p class="margin-top-10 margin-bottom-20">We are tremendously excited to have the opportunity to become your supplier of choice. In more and more states people have the freedom to choose their own supplier. We have just begun to grow and, with this growth, we will have new and exciting products developed for our client base. We hope to start a relationship with you that begins with electricity service and develops into much more.</p>
                        <div class="btn btn-default">
                            <a class="info" href="http://localhost/build/substance/index.php/quam-nunc-putamus">Read more</a>
                        </div>
                    </a>
                </div>
            </div>
            <!-- //Portfolio Item// -->
            <!-- Portfolio Item -->
            <div class="portfolio-item col-sm-4 animate fadeIn">
                <div class="image-hover">
                    <a href="#">
                        <figure>
                            {!! Html::image('images/learn-square.png', 'learn-more', array('class' => 'img-square img-responsive img-center learn')) !!}
                            <div class="overlay">
                                <a class="expand" href="#">Image Link</a>
                            </div>
                        </figure>
                        <h3 class="margin-top-20">Learn More</h3>
                        <p class="margin-top-10 margin-bottom-20">Great American Power is approved and licensed by the Pennsylvania Public Utilities Commission and the Maryland Public Service Commission. We currently provide electric service in PPL, PECO, Duquesne, BGE, Delmarva and PEPCO utility territories.</p>
                        <div class="btn btn-default">
                            <a class="info" href="http://localhost/build/substance/index.php/quam-nunc-putamus">Read more</a>
                        </div>
                    </a>
                </div>
            </div>
            <!-- //Portfolio Item// -->
            <!-- Portfolio Item -->
            <div class="portfolio-item col-sm-4 animate fadeIn">
                <div class="image-hover">
                    <a href="#">
                        <figure>
                            {!! Html::image('images/contact-square.png', 'contact-us', array('class' => 'img-square img-responsive img-center contact')) !!}
                            <div class="overlay">
                                <a class="expand" href="#">Image Link</a>
                            </div>
                        </figure>
                        <h3 class="margin-top-20">Contact Us</h3>
                        <p class="margin-top-10 margin-bottom-20">If you have a question about your account, service, or our plans, please contact one of our customer care agents.</p>
                        <div class="btn btn-default">
                            <a class="info" href="http://localhost/build/substance/index.php/quam-nunc-putamus">Read more</a>
                        </div>
                    </a>
                </div>
            </div>
            <!-- //Portfolio Item// -->
            <!-- End Portfolio -->
        </div>
        <div class="row">
            <h2 class="text-center margin-top-10">Great American Power, LLC</h2>
            <p class="text-center margin-bottom-30">Aenean venenatis egestas iaculis. Donec non urna quam. Nullam consectetur condimentum dolor at bibendum.</p>
        </div>
    </div>
</div>
@endsection