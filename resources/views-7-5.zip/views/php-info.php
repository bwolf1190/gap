<?php

echo phpinfo();


?>