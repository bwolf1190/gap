<!-- Acc Num Field -->
<div class="form-group">
    {!! Form::label('acc_num', 'Acc Num:') !!}
    <p>{!! $customer->acc_num !!}</p>
</div>

<!-- Fname Field -->
<div class="form-group">
    {!! Form::label('fname', 'Fname:') !!}
    <p>{!! $customer->fname !!}</p>
</div>

<!-- Lname Field -->
<div class="form-group">
    {!! Form::label('lname', 'Lname:') !!}
    <p>{!! $customer->lname !!}</p>
</div>

<!-- Sa1 Field -->
<div class="form-group">
    {!! Form::label('sa1', 'Sa1:') !!}
    <p>{!! $customer->sa1 !!}</p>
</div>

<!-- Sa2 Field -->
<div class="form-group">
    {!! Form::label('sa2', 'Sa2:') !!}
    <p>{!! $customer->sa2 !!}</p>
</div>

<!-- Scity Field -->
<div class="form-group">
    {!! Form::label('scity', 'Scity:') !!}
    <p>{!! $customer->scity !!}</p>
</div>

<!-- Sstate Field -->
<div class="form-group">
    {!! Form::label('sstate', 'Sstate:') !!}
    <p>{!! $customer->sstate !!}</p>
</div>

<!-- Szip Field -->
<div class="form-group">
    {!! Form::label('szip', 'Szip:') !!}
    <p>{!! $customer->szip !!}</p>
</div>

<!-- Ma1 Field -->
<div class="form-group">
    {!! Form::label('ma1', 'Ma1:') !!}
    <p>{!! $customer->ma1 !!}</p>
</div>

<!-- Ma2 Field -->
<div class="form-group">
    {!! Form::label('ma2', 'Ma2:') !!}
    <p>{!! $customer->ma2 !!}</p>
</div>

<!-- Mcity Field -->
<div class="form-group">
    {!! Form::label('mcity', 'Mcity:') !!}
    <p>{!! $customer->mcity !!}</p>
</div>

<!-- Mstate Field -->
<div class="form-group">
    {!! Form::label('mstate', 'Mstate:') !!}
    <p>{!! $customer->mstate !!}</p>
</div>

<!-- Mzip Field -->
<div class="form-group">
    {!! Form::label('mzip', 'Mzip:') !!}
    <p>{!! $customer->mzip !!}</p>
</div>

<!-- Same Address Field -->
<div class="form-group">
    {!! Form::label('same_address', 'Same Address:') !!}
    <p>{!! $customer->same_address !!}</p>
</div>

<!-- Email Field -->
<div class="form-group">
    {!! Form::label('email', 'Email:') !!}
    <p>{!! $customer->email !!}</p>
</div>

<!-- Confirm Email Field -->
<div class="form-group">
    {!! Form::label('confirm_email', 'Confirm Email:') !!}
    <p>{!! $customer->confirm_email !!}</p>
</div>

<!-- Phone Field -->
<div class="form-group">
    {!! Form::label('phone', 'Phone:') !!}
    <p>{!! $customer->phone !!}</p>
</div>

<!-- Promo Field -->
<div class="form-group">
    {!! Form::label('promo', 'Promo:') !!}
    <p>{!! $customer->promo !!}</p>
</div>

